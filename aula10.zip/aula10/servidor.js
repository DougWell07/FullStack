var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');
var mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
const uri = 'mongodb+srv://dougwell:cRMBGweothHG1e0y@fei.4f944b3.mongodb.net/?appName=FEI';
const client = new MongoClient(uri);

var app = express();

app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: false}));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', "./views");

var usuarios;
var carros;

// conecta ao banco antes de iniciar o servidor
client.connect().then(function() {
    console.log('Conectado ao MongoDB!'.green);
    var dbo = client.db("projeto_carros");
    usuarios = dbo.collection("usuarios");
    carros = dbo.collection("carros");

    var server = http.createServer(app);
    server.listen(80);
    console.log('Servidor rodando ...'.rainbow);
}).catch(function(err) {
    console.log('Erro ao conectar ao MongoDB:'.red, err);
});

// página inicial 
app.get('/', function(requisicao,resposta){
    resposta.redirect('cadastro.html');
});

// cadastro de usuário 
app.post('/cadastro', function(req, resp){
   var data = {db_nome: req.body.nome, db_login: req.body.login, db_senha: req.body.senha };
   usuarios.insertOne(data, function(err){
    if (err){
        console.log(err);
        resp.render('resposta_usuario.ejs', {resposta: "Erro ao cadastrar usuário!"});
    }else{
        resp.render('resposta_usuario.ejs', {resposta: "Usuário cadastrado com sucesso!"});
    }
   });
});

// login de usuário 
app.post("/login", function(req, resp){
    var data = {db_login: req.body.login, db_senha: req.body.senha};
    usuarios.find(data).toArray(function (err, items){
        console.log(items);
        if (items.length == 0){
            resp.render('resposta_usuario.ejs', {resposta: "Usuário/senha não encontrado!"});
        } else if(err){
            resp.render('resposta_usuario.ejs', {resposta: "Erro ao logar usuário!"});
        } else{
            resp.redirect('/gerencia');
        }
    });
});

// listagem dos carros
app.get('/carros', function(req, resp){
    carros.find({}).toArray(function(err, items){
        console.log(items);
        if (err) {
            resp.render('resposta_usuario', {resposta: "Erro ao buscar carros!"});
        } else {
            resp.render('carros', {carros: items});
        }
    });
});

// gerência 
app.get('/gerencia', function(req, resp) {
  carros.find({}).toArray(function(err, items) {
    if (err) {
      resp.render('resposta_usuario', { resposta: "Erro ao buscar carros!" });
    } else {
      resp.render('gerencia', { carros: items });
    }
  });
});

// cadastrar novo carro
app.post('/carros/cadastrar', function(req, resp){
    var data = { 
        db_marca: req.body.marca, 
        db_modelo: req.body.modelo, 
        db_ano: req.body.ano,
        db_quantidade: req.body.quantidade
    };
    carros.insertOne(data, function(err){
        console.log(err);
        if (err){
            resp.render('resposta_usuario', {resposta: "Erro ao cadastrar carro!"})
        } else{
            resp.render('resposta_usuario', {resposta: "Carro cadastrado com sucesso!"})
        }
    });
});


// remover carro
app.post('/carros/remover', function(req, resp) {
  var data = { db_marca: req.body.marca, db_modelo: req.body.modelo, db_ano: req.body.ano };
  var quantidade = parseInt(req.body.quantidade);
  var newData = { $inc: { db_quantidade: -quantidade } };
  carros.updateOne(data, newData, function(err, result) {
    if (err) {
      resp.render('resposta_usuario', { resposta: "Erro ao remover carro!" });
    } else if (result.modifiedCount == 0) {
      resp.render('resposta_usuario', { resposta: "Carro não encontrado!" });
    } else {
      resp.render('resposta_usuario', { resposta: "Quantidade removida com sucesso!" });
    }
  });
});

// remover carro
app.post('/carros/remover', function(req, resp) {
  var data = { 
    db_marca: req.body.marca, 
    db_modelo: req.body.modelo, 
    db_ano: String(req.body.ano)
  };
  var quantidade = parseInt(req.body.quantidade);
  var newData = { $inc: { db_quantidade: -quantidade } };
  carros.updateOne(data, newData, function(err, result) {
    console.log('err:', err);
    console.log('result:', result);
    if (err) {
      resp.render('resposta_usuario', { resposta: "Erro ao remover carro!" });
    } else if (result.modifiedCount == 0) {
      resp.render('resposta_usuario', { resposta: "Carro não encontrado!" });
    } else {
      resp.render('resposta_usuario', { resposta: "Quantidade removida com sucesso!" });
    }
  });
});

// vender carro
app.post('/carros/vender', function(req, resp) {
  var data = { 
    db_marca: req.body.marca, 
    db_modelo: req.body.modelo, 
    db_ano: String(req.body.ano)
  };
  var quantidade = parseInt(req.body.quantidade);
  var newData = { $inc: { db_quantidade: -quantidade } };
  carros.updateOne(data, newData, function(err, result) {
    console.log('err:', err);
    console.log('result:', result);
    if (err) {
      resp.render('resposta_usuario', { resposta: "Erro ao vender carro!" });
    } else if (result.modifiedCount == 0) {
      resp.render('resposta_usuario', { resposta: "Carro não encontrado ou esgotado!" });
    } else {
      resp.render('resposta_usuario', { resposta: "Carro vendido com sucesso!" });
    }
  });
});

// atualizar carro
app.post('/carros/atualizar', function(req, resp) {
  var data = { db_marca: req.body.marca_atual, db_modelo: req.body.modelo_atual, db_ano: req.body.ano_atual };
  var newData = { $set: {
    db_marca: req.body.marca,
    db_modelo: req.body.modelo,
    db_ano: req.body.ano,
    db_quantidade: req.body.quantidade
  }};
  carros.updateOne(data, newData, function(err, result) {
    if (err) {
      resp.render('resposta_usuario', { resposta: "Erro ao atualizar carro!" });
    } else if (result.modifiedCount == 0) {
      resp.render('resposta_usuario', { resposta: "Carro não encontrado!" });
    } else {
      resp.render('resposta_usuario', { resposta: "Carro atualizado com sucesso!" });
    }
  });
});