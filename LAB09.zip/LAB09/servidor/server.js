const express = require('express');
const path    = require('path');

const app  = express();
const PORT = 80;

// ── Banco de dados em memória ──────────────────────────────
const usuarios = [];
const posts    = [];   // BD de posts

// ── Configurações ──────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ── Rotas GET ──────────────────────────────────────────────

// Rota padrão → página de projetos
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

// Página de cadastro de usuário
app.get('/cadastrar', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Cadastro.html'));
});

// Página de login
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Login.html'));
});

// Blog — busca todos os posts e renderiza a página dinâmica
app.get('/blog', (req, res) => {
    res.render('blog', { posts: posts });
});

// Formulário para cadastrar novo post
app.get('/cadastrar_post', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cadastrar_post.html'));
});

// ── Rotas POST ─────────────────────────────────────────────

// Processar cadastro de usuário
app.post('/cadastrar', (req, res) => {
    const { nome, email, senha } = req.body;

    const jaExiste = usuarios.find(u => u.email === email);
    if (jaExiste) {
        return res.render('resposta', {
            titulo:   'Erro no Cadastro',
            sucesso:  false,
            email:    email,
            mensagem: 'Este e-mail já está cadastrado.'
        });
    }

    usuarios.push({ nome, email, senha });
    console.log('Novo usuário cadastrado:', { nome, email });

    return res.render('resposta', {
        titulo:   'Cadastro realizado',
        sucesso:  true,
        email:    email,
        mensagem: 'Cadastro realizado com sucesso!'
    });
});

// Processar login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    const usuario = usuarios.find(u => u.email === email && u.senha === senha);

    if (usuario) {
        return res.render('resposta', {
            titulo:   'Login bem-sucedido',
            sucesso:  true,
            email:    usuario.email,
            mensagem: 'Login realizado com sucesso!'
        });
    } else {
        return res.render('resposta', {
            titulo:   'Login inválido',
            sucesso:  false,
            email:    email,
            mensagem: 'E-mail ou senha incorretos. Tente novamente ou cadastre-se.'
        });
    }
});

// Cadastrar novo post no banco de dados
app.post('/cadastrar_post', (req, res) => {
    const { titulo, resumo, conteudo } = req.body;

    // Formata a data atual
    const agora = new Date();
    const data  = agora.toLocaleDateString('pt-BR', {
        day:   '2-digit',
        month: '2-digit',
        year:  'numeric'
    });

    // Salva o post no BD em memória
    posts.push({ titulo, resumo, conteudo, data });
    console.log('Novo post cadastrado:', { titulo, data });

    // Redireciona para o blog após salvar
    res.redirect('/blog');
});

// ── Iniciar servidor ───────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});